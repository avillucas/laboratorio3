var heroe = "Ricardo Tapia (Robin)";
var edad = 30;
function imprimir(herote, edad) {
    heroe = heroe.toLowerCase();
    edad = edad + 10;
    return heroe + " " + edad;
}
console.log(imprimir(heroe, edad));
