
import { PI } from "./validaciones/numeros";


console.log(PI);