"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var numeros_1 = require("./validaciones/numeros");
console.log(numeros_1.PI);
