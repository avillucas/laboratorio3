export const PI = 3.1416;

export function restar(num1:number, num2:number):number{
    return num1 - num2;
}

