var mensajes = [
    "El texto es muy corto",
    ">El texto es muy largo"
];
function obtenerError(numError) {
    return mensajes[numError];
}
