"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PI = 3.1416;
function restar(num1, num2) {
    return num1 - num2;
}
exports.restar = restar;
