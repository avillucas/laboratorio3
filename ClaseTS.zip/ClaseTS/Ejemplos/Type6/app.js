if (Validations.validarTexto("Barry Allen")) {
    console.log("El texto es válido");
}
else {
    console.log("El texto no es válido");
}
