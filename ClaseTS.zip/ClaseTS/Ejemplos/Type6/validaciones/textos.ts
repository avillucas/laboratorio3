namespace Validations {

    export function validarTexto(texto: string): boolean {
    if (Text.length >3) {
        return true;
    }
    return false;
}

}
