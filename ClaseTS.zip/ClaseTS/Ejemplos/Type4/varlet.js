var nombre = "Tony";
if (true) {
    var nombre = "Bruce";
}
console.log(nombre);
