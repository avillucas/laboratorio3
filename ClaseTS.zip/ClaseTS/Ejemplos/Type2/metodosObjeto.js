"use strict";
var flash = {
    nombre: "Barry Allen",
    edad: 24,
    poderes: ["Corre muy rápido", "Viaja en el tiempo"],
    getNombre: function () {
        return this.nombre;
    }
};
// flash.getNombre();
