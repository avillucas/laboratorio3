let flash = {
    nombre: "Barry Allen",
    edad: 24,
    poderes: ["Corre muy rápido", "Viaja en el tiempo"]
};

flash = {
    nombre: "Clark Kent",
    edad:500,
    poderes:["Vuela", "Superfuerza", "Mirada laser"]
}