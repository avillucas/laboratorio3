//no influye el orden

let flash: { nombre:string, edad:number, poderes:string[]}= {
    nombre: "Barry Allen",
    edad: 24,
    //edad:"24",
    poderes: ["Corre muy rápido", "Viaja en el tiempo"]

    //getNombre(){   }
    
    
};

// flash.getNombre();

