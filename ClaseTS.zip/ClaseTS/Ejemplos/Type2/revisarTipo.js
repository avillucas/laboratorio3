"use strict";
var cosa = 123;
if (typeof (cosa) === "number") {
    console.log("Cosa en un " + cosa);
}
