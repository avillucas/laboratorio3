"use strict";
var loQueSea;
loQueSea = "Juan";
loQueSea = 36,
    loQueSea = {
        nombre: "Flash",
        edad: 24
    };
