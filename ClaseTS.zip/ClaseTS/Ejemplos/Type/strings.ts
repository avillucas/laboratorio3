let batman:string= "Batman";
let superman:string= "Superman";
let linternaVerde:string= `Linterna Verde`;

let frase:string = "Los Heroes son: " + batman + ", " + superman + ", "+ linternaVerde;

let concat:string = `Los Heroes son: ${batman}, ${superman}, ${linternaVerde}`;

console.log(frase);
console.log(concat);