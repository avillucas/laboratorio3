var avengers = 5;
var villanos;
var otros = 2;
if (avengers > villanos) {
    console.log("Estamos Salvados!!!");
}
else {
    console.log("Estamos Muertos!!!");
}
otros = 123;
otros = 234.5;
//otros= "Hola";
