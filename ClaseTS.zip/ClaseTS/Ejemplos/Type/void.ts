function llamarABatman():void{
    console.log("Mostrar la Batiseñal");
}