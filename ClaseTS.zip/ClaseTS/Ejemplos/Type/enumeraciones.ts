enum Volumen{

    min, 
    medio,
    maximo


}

console.log(Volumen["medio"]);