


abstract class Mutante{

    constructor(public nombre:string, public nombreReal:string){

    }
}
class Xmenx extends Mutante{

}

let wolverine = new Xmenx("Wolverine", "Logan");