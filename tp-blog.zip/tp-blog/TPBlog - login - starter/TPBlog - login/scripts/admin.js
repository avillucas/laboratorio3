//Saacar el tocken para que quede deslogueado 
window.onload = function ()
{
	$('#logoff').click(function(e){

		//eliminar el tocken 
		//redireccionar a login  
	});
}