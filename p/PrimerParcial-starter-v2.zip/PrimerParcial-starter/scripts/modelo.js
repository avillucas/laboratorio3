function mostrarFormulario(heroe)
{

}