<?php 
sleep(3);
echo file_get_contents('data'.DIRECTORY_SEPARATOR.'autos.json');