
//aca va el constructor de la entidad heroe
//var Heroe = function (){};


function Personaje(id, nombre, apellido, alias, edad, lado, editorial) {
    //contructor de objeto Personaje
    this.id = id ;
    this.nombre= nombre;
    this.apellido = apellido ;
    this.alias = alias ;
    this.edad = edad;
    this.lado = lado ;    
    this.editorial =editorial ;    
}