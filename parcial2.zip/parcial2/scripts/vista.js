function actualizarTabla(lista)
{  
    escribirtablaFiltrada(lista,true,true,true,true,true,true,true,true);
    calcularPromedioYMasViejo(lista);
}

function escribirtablaFiltrada(collection,chkId,chkName,chkApellido,chkAlias,chkEdad, chkLado, chkEditorial)
{         
   var tabla = '<thead>';
    if(chkId)
        tabla += "<th>Id</th>";
    if(chkName)
        tabla += "<th>Nombre</th>";
    if(chkApellido)
        tabla += "<th>Apellido</th>";
    if(chkAlias)
        tabla += "<th>Alias</th>";
    if(chkEdad)
        tabla+= "<th>Edad</th>";                
    if(chkLado)
        tabla += "<th>Lado</th>";
    if(chkEditorial)
        tabla += "<th>Editorial</th>";
    tabla += "</tr></thead><tbody>";   
    for(c in collection)
    {                   
        if (collection.length == 0) {
            tabla += "<tr><td colspan='7'>No hay heroes que mostrar</td></tr>";
        }else {                    
            for (let i = 0; i < collection.length; i++) {
                var heroe = collection[i];
                var editorial =  ( typeof heroe.editorial == 'undefined') ?  'No Definido' : heroe.editorial;    
                var clase = (heroe.activo) ? ' heroe_activo ':'';                
                tabla += '<tr class=" table '+clase+' filaHeroe "  data-id="'+heroe.id+'">';                
                if(chkId)
                    tabla += '<td>'+heroe.id+'</td>';
                if(chkName)
                    tabla += heroe.nombre;
                    tabla += '<td>'+heroe.nombre+'</td>';
                if(chkApellido)
                    tabla += '<td>'+heroe.apellido+'</td>';
                if(chkAlias)                    
                    tabla += '<td>'+heroe.alias+'</td>';
                if(chkEdad)                    
                    tabla += '<td>'+heroe.edad+'</td>';
                if(chkLado)
                    tabla += '<td>'+heroe.lado+'</td>';
                if(chkEditorial)                   
                   tabla += '<td>'+heroe.editorial+'</td>';
                tabla += `</tr>`;             
            }
        }
       // tabla += `<tbody>`;
    }
    $('#listTable').html(tabla);
    //document.getElementsByClassName('filaClickeable').onclick = traerIdHeroe;
    $('#listTable tr.filaHeroe').click(traerIdHeroe);
}

function lanzarSpinner(callback)
{
    //$('#spinner').show();
    if(typeof callback != 'undefined')
    {
        callback;
    }
}

function cortarSpinner(callback)
{
    $('#spinner').hide();    
    if(typeof callback != 'undefined')
    {
        callback;
    }
}
function ocultarFormulario()
{
    $('#agregarSection').hide(); 
}

function mostrarFormulario(heroe)
{        
    if(typeof heroe !== 'undefined')
    {
        if(typeof heroe.editorial == 'undefined')    
        {
            alert("Se ha puesto 'Otro' como valor por defecto debera guardar los cambios.");
            heroe.editorial = 'otro';
        }
        $('#idField').val(heroe.id).attr('disabled',true);
        $('#nombreField').val(heroe.nombre);
        $('#apellidoField').val(heroe.apellido);
        $('#aliasField').val(heroe.alias);
        $('#edadField').val(heroe.edad);
        //$('#ladoField').val(heroe.lado),                
        $('#ladoField[value="'+heroe.lado+'"]').attr('checked',true),                
        $('#activeField').attr('checked',(heroe.active));                   
        $('#editorialField').val(heroe.editorial);    
        $('#btnModificarForm').show();
        $('#btnEliminarForm').show();      
        $('#btnAltaForm').hide();
    }
    else
    {           
        $('#idField').val("").attr('disabled',false);
        $('#nombreField').val("");
        $('#apellidoField').val("");
        $('#aliasField').val("");
        $('#edadField').val("");
        $('#editorialField').val("otro");
        $('#ladoField[value="heroe"]').attr('checked',true),                        
        $('#btnModificarForm').hide();
        $('#btnEliminarForm').hide();
        $('#btnAltaForm').show();
    }
    document.getElementById('agregarSection').style.display = "block";
   // $('#agregarSection').show();   
}

function mostrarSeccionLista()
{
    $('#listSection').show();   
    ejecutarTransaccion("Mostrar");
}
function ocultarSeccionLista()
{
    $('#listSection').hide();   
}

function ocultarFormulario()
{
    document.getElementById('agregarSection').style.display = "none";
}