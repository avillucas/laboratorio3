var Clases;
(function (Clases) {
    var ladoHeroe;
    (function (ladoHeroe) {
        ladoHeroe[ladoHeroe["Heroe"] = 0] = "Heroe";
        ladoHeroe[ladoHeroe["Villano"] = 1] = "Villano";
    })(ladoHeroe = Clases.ladoHeroe || (Clases.ladoHeroe = {}));
    var editorialHeroe;
    (function (editorialHeroe) {
        editorialHeroe[editorialHeroe["Dc"] = 0] = "Dc";
        editorialHeroe[editorialHeroe["Marvel"] = 1] = "Marvel";
    })(editorialHeroe = Clases.editorialHeroe || (Clases.editorialHeroe = {}));
})(Clases || (Clases = {}));
