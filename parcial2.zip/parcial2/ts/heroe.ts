//realizar codigo de la clase "Heroe". el metodo toJSON es parte de la clase y es provisto en el starter
///<reference path="personaje.ts"/>
namespace Clases{

    export class Heroe extends Personaje{

        private _id:number;
        public lado:Clases.ladoHeroe;
        public editorial:Clases.editorialHeroe;
        public alias:string;
        
        constructor( id:number,  nombre:string, apellido:string, alias:string, edad:number, lado:Clases.ladoHeroe, editorial:Clases.editorialHeroe )
        {
            super(nombre,apellido,edad);
            this._id = id;
            this.lado = lado;
            this.editorial = editorial;
            this.alias = alias;
        }

        public toJSON():string{
            let cad:string = super.toJSON().replace('}', '');                      
            let json:string = cad + `, "id":${this.id}, "lado":"${this.lado.toString()}", "editorial":"${this.editorial}", "alias":"${this.alias}"}`;
            return json;
        }

        public get id():number
        {
            return this._id;
        }

        public set id(value:number)
        {
            this._id = value;
        }
    }
}

