namespace Clases{

   export enum ladoHeroe{
        Heroe,
        Villano
    }

    export enum editorialHeroe{
        Dc,
        Marvel
    }

}