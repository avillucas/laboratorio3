///<reference path="heroe.ts"/>
/*
$(function () {
    cargarTipos();
    mostrarHeroes();
    $('#cmbFiltro').change(function () {
        filtrarHeroes(Number($(this).val()));
    });
    $('#cmbFiltro').change(function () {
        filtrarHeroes(Number($(this).val()));
    });
    //agregar al evento change de los 4 checkbox, el manejador "mapearCampos"
    $('#chkId, #chkName, #chkEdad, #chkPoder').change(function () {
        mapearCampos();
    });
    $('#btnAgregar').click(function(e){
        agregarHeroe();
    });
    $('#btnModificar').click(function(e){
        modificarHeroe();
    });
   
});
*/
function insertarHeroe(nuevoHeroe) {
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    HeroesJSON.push(JSON.parse(nuevoHeroe.toJSON()));
    localStorage.setItem("Heroes", JSON.stringify(HeroesJSON));
    alert("Heroe guardado!!!");
    ocultarFormulario();
    cortarSpinner();
    traerListaHeroes(manejarActualizarLista);
}
//traerListaHeroes
function traerListaHeroes(callback) {
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    callback(HeroesJSON);
    //return HeroesJSON;
}
function cargarTipos() {
    for (var i = 0; i < Object.keys(Clases.ladoHeroe).length / 2; i++) {
        $("#cmbFiltro").append('<option value="' + Clases.ladoHeroe[i] + '">' + Clases.ladoHeroe[i] + '</option>');
    }
}
function filtrarHeroes(tipo) {
    var heroesFiltrados;
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    if (tipo.toLowerCase() == 'todos')
        return HeroesJSON;
    //en "heroesFiltrados", aplicar el filtro por tipo.
    heroesFiltrados = HeroesJSON.filter(function (heroe) {
        //AYUDA. Usar el siguiente codigo: Clases.tipoHeroe[Heroe.tipo] === Clases.tipoHeroe[tipo]                            
        return heroe.lado.toString().toLowerCase() === tipo.toLowerCase();
    });
    //mostrarHeroesPorTipo(heroesFiltrados);
    escribirtablaFiltrada(heroesFiltrados, true, true, true, true, true, true, true, true);
}
function calcularPromedioYMasViejo(heroesFiltrados) {
    var promedio = 0;
    var totalEdades;
    var cantidad;
    var tipo = Number($('#cmbFiltro').val());
    var masViejo = heroesFiltrados.reduce(function (anterior, actual) {
        if (anterior == 0)
            return actual;
        return (actual.edad > anterior.edad) ? actual : anterior;
    }, 0);
    //calcular suma de edades
    totalEdades = heroesFiltrados.reduce(function (anterior, actual) {
        return anterior += actual.edad;
    }, 0);
    cantidad = heroesFiltrados.length;
    //se calcula el promedio
    if (cantidad != 0) {
        promedio = totalEdades / cantidad;
    }
    //asignar promedio  al valor de txtPromedio, usando jQuery
    $('#txtPromedio').val(promedio);
    $('#txtMasViejo').val(masViejo.nombre);
}
function mapearCampos() {
    var chkId = $('#chkId')[0].checked;
    var chkName = $('#chkName')[0].checked;
    var chkApellido = $('#chkApellido')[0].checked;
    var chkAlias = $('#chkAlias')[0].checked;
    var chkEdad = $('#chkEdad')[0].checked;
    var chkLado = $('#chkLado')[0].checked;
    var chkEditorial = $('#chkEditorial')[0].checked;
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    escribirtablaFiltrada(HeroesJSON, chkId, chkName, chkApellido, chkAlias, chkEdad, chkLado, chkEditorial);
}
//agregar el codigo que crea conveniente para realizar las bajas y las modificaciones
function eliminarHeroe(heroeAEliminar) {
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    for (var i = 0; i < HeroesJSON.length; i++) {
        if (HeroesJSON[i].id == heroeAEliminar.id) {
            //HeroesJSON[i] = null;
            HeroesJSON.splice(i, 1);
            break;
        }
    }
    localStorage.setItem("Heroes", JSON.stringify(HeroesJSON));
    ocultarFormulario();
    cortarSpinner();
    traerListaHeroes(manejarActualizarLista);
}
function modificarHeroe(heroeModificado) {
    var HeroesString = localStorage.getItem("Heroes");
    var HeroesJSON = HeroesString == null ? [] : JSON.parse(HeroesString);
    for (var i = 0; i < HeroesJSON.length; i++) {
        if (HeroesJSON[i].id == heroeModificado.id) {
            HeroesJSON[i] = JSON.parse(heroeModificado.toJSON());
            break;
        }
    }
    //guardar HeroesJSON en localStorage con el nombre "Heroes"
    localStorage.setItem("Heroes", JSON.stringify(HeroesJSON));
    lanzarSpinner();
    ocultarFormulario();
    cortarSpinner();
    traerListaHeroes(manejarActualizarLista);
}
function cleanStorage() {
    localStorage.clear();
    alert("LocalStorage Limpio");
}
