var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//realizar codigo de la clase "Heroe". el metodo toJSON es parte de la clase y es provisto en el starter
///<reference path="personaje.ts"/>
var Clases;
(function (Clases) {
    var Heroe = /** @class */ (function (_super) {
        __extends(Heroe, _super);
        function Heroe(id, nombre, apellido, alias, edad, lado, editorial) {
            var _this = _super.call(this, nombre, apellido, edad) || this;
            _this._id = id;
            _this.lado = lado;
            _this.editorial = editorial;
            _this.alias = alias;
            return _this;
        }
        Heroe.prototype.toJSON = function () {
            var cad = _super.prototype.toJSON.call(this).replace('}', '');
            var json = cad + (", \"id\":" + this.id + ", \"lado\":\"" + this.lado.toString() + "\", \"editorial\":\"" + this.editorial + "\", \"alias\":\"" + this.alias + "\"}");
            return json;
        };
        Object.defineProperty(Heroe.prototype, "id", {
            get: function () {
                return this._id;
            },
            set: function (value) {
                this._id = value;
            },
            enumerable: true,
            configurable: true
        });
        return Heroe;
    }(Clases.Personaje));
    Clases.Heroe = Heroe;
})(Clases || (Clases = {}));
