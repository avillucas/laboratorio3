///<reference path="enumerados.ts"/>

namespace Clases{

export abstract class Personaje{
    public nombre:string;
    public apellido:string;
    public edad:number;
   

    //hacer constructor
    constructor(nombre:string ,apellido:string , edad:number)
    {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public toJSON():string{
        let json: string = `{"nombre":"${this.nombre}","apellido":"${this.apellido}", "edad":${this.edad}}`;
        return json;
    }

}

}