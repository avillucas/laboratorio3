///<reference path="enumerados.ts"/>
var Clases;
(function (Clases) {
    var Personaje = /** @class */ (function () {
        //hacer constructor
        function Personaje(nombre, apellido, edad) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
        }
        Personaje.prototype.toJSON = function () {
            var json = "{\"nombre\":\"" + this.nombre + "\",\"apellido\":\"" + this.apellido + "\", \"edad\":" + this.edad + "}";
            return json;
        };
        return Personaje;
    }());
    Clases.Personaje = Personaje;
})(Clases || (Clases = {}));
