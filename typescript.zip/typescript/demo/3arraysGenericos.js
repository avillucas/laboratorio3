"use strict";
// Array Generico
let Heroes = ["Flash", "Superman", "Batman"];
// Array Explicito
let villanos = ["Lex Luthor", "The Joker"];
//# sourceMappingURL=3arraysGenericos.js.map