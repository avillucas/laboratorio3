"use strict";
/*
function funcionGenerica<T>( parametro:T){
    return parametro;
}

type Heroe = {
    nombre: string,
    nombreReal: string
}

type Villano = {
    nombre: string,
    poder: string
}

let deadpool ={
    nombre: "Deadpool",
    nombreReal: "Wade Winston Wilson",
    poder: "Regeneración"
};

console.log( funcionGenerica(deadpool). );
*/
function funcionGenerica(parametro) {
    return parametro;
}
let deadpool = {
    nombre: "Deadpool",
    nombreReal: "Wade Winston Wilson",
    poder: "Regeneración"
};
console.log(funcionGenerica(deadpool).);
//# sourceMappingURL=2funcionGenerica.js.map