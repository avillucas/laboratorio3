"use strict";
/*

class Rectangulo {
    base;
    altura;
    area():number{
        return this.base * this.altura;
    }
}

let rectangulo = new Rectangulo();

rectangulo.base = 10;
rectangulo.altura = 10;

console.log(rectangulo.area());


*/
class Rectangulo {
    area() {
        return this.base * this.altura;
    }
}
let rectangulo = new Rectangulo();
rectangulo.base = 10;
rectangulo.altura = 10;
console.log(rectangulo.area());
//# sourceMappingURL=3clasesGenericas.js.map