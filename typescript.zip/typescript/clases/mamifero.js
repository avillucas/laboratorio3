"use strict";
class Mamifero {
    constructor(colorPelo) {
        this.colorPelo = colorPelo;
    }
}
//# sourceMappingURL=mamifero.js.map