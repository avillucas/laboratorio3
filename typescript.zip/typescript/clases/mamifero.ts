
abstract class Mamifero
{
    private colorPelo:string;

    constructor(colorPelo:string){
        this.colorPelo = colorPelo;
    }
}